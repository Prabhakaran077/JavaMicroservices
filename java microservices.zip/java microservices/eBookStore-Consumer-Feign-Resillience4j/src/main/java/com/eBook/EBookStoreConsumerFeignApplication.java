package com.eBook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients

public class EBookStoreConsumerFeignApplication {

	public static void main(String[] args) {
		SpringApplication.run(EBookStoreConsumerFeignApplication.class, args);
	}

}
