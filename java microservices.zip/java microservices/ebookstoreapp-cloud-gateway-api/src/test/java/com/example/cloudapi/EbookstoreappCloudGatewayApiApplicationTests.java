package com.example.cloudapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EbookstoreappCloudGatewayApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
