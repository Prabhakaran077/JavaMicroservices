package com.ebook.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ebook.entity.Book;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {

	List<Book> findByBookTitle(String title);

	List<Book> findByBookPublisherLike(String publisher);

	List<Book> findByBookYear(int year);
}
