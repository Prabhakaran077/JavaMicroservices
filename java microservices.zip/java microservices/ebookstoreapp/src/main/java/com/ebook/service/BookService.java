package com.ebook.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ebook.entity.Book;
import com.ebook.repository.BookRepository;

@Service
public class BookService {

	private final BookRepository bookRepository;

	@Autowired
	public BookService(BookRepository bookRepository) {
		this.bookRepository = bookRepository;
	}

	public void addBook(Book book) {
		bookRepository.save(book);
	}

	public void updateBook(Book book) {
		bookRepository.save(book);
	}

	public List<Book> getAllBooks() {
		return bookRepository.findAll();
	}

	public Optional<Book> getBookById(Long bookId) {
		return bookRepository.findById(bookId);
	}

	public void deleteBookById(Long bookId) {
		bookRepository.deleteById(bookId);
	}

	public List<Book> getBooksByTitle(String title) {
		return bookRepository.findByBookTitle(title);
	}

	public List<Book> getBooksByPublisher(String publisher) {
		return bookRepository.findByBookPublisherLike(publisher);
	}

	public List<Book> getBooksByYear(int year) {
		return bookRepository.findByBookYear(year);
	}
}
