package com.eBook.fallback;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Component;
import com.eBook.entity.Book;
import com.eBook.proxy.BookServiceProxy;

@Component
public class BookServiceFallback implements BookServiceProxy{

	@Override
	public List<Book> getAllBooks() {
		return new ArrayList<Book>();
	}

	@Override
	public Optional<Book> getBookById(Long bookId) {
		return Optional.ofNullable(new Book("Java MS 1", "RamNath", "978-1-61729-427-3", 256, 2014));
	}

}
