package com.eBook.proxy;

import java.util.List;
import java.util.Optional;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.eBook.entity.Book;

@FeignClient("book-service")
public interface BookServiceProxy {
	@GetMapping("/books")
	public List<Book> getAllBooks();

	@GetMapping("/books/{book_id}")
	public Optional<Book> getBookById(@PathVariable("book_id") Long bookId);
}
