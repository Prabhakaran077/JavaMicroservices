package com.eBook.Controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.eBook.entity.Book;
import com.eBook.proxy.BookServiceProxy;

@RestController
@Scope("request")
public class BookConsumerRestController {

    @Autowired
    private BookServiceProxy bookServiceProxy;

    private static final Logger log = LoggerFactory.getLogger(BookConsumerRestController.class);

    @GetMapping("/get-books/{book_id}")
    public Optional<Book> getBookById(@PathVariable("book_id") Long bookId) {
        log.debug("getBookById with Id:" + bookId);
        Optional<Book> book = bookServiceProxy.getBookById(bookId);
        log.debug("getBookById with return value book:" + book);
        return book;
    }

    @GetMapping("/get-books")
    public List<Book> getAllBooks() {
        List<Book> books = bookServiceProxy.getAllBooks();
        log.debug("getAllBooks with return value books:" + books);
        return books;
    }
}

//@Scope("request")
//public class BookConsumerRestController {
//
//	@Autowired
//	private BookServiceProxy bookServiceProxy;
//
//	private static final Logger log = LoggerFactory.getLogger(BookConsumerRestController.class);
//
//
//	@GetMapping("/get-books/{book_id}")
//	public Optional<Book> getBookById(@PathVariable("book_id") Long bookId) {
//		
//		log.debug("getBookById with Id:" + bookId);
//		Optional<Book> book = bookServiceProxy.getBookById(bookId);
//		log.debug("getBookById with return value book:" + book);
//		return book;
//
//	}
//
//	@GetMapping("/get-books")
//	public List<Book> getAllBooks() {
//		List<Book> book = bookServiceProxy.getAllBooks();
//		log.debug("getAllBooks with return value book:" + book);
//		return book;
//	}
//
//}
