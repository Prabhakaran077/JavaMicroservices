


package com.eBook.proxy;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.eBook.entity.Book;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "book-service")
public interface BookServiceProxy {
	@Retry(name="book-service")
	@CircuitBreaker(name = "book-service", fallbackMethod = "fallbackForGetAllBooks")
	@GetMapping("/books")
	public List<Book> getAllBooks();
	
	@Retry(name="book-service")
	@CircuitBreaker(name = "book-service", fallbackMethod = "fallbackForGetBookById")
	@GetMapping("/books/{book_id}")
	public Optional<Book> getBookById(@PathVariable("book_id") Long bookId);
	
	default Optional<Book> fallbackForGetBookById(Long bookId, Throwable throwable) {
        System.out.println("Exception Raised with the message: ===>" + throwable.getMessage());
        return Optional.ofNullable(new Book("Java MS 1", "RamNath", "978-1-61729-427-3", 256, 2014));
    }
		
	default List<Book> fallbackMethodGetAllBooks (Throwable throwable) { 
		System.out.println("Exception raised with message :*>" + throwable.getMessage()); 
		return Arrays.asList();
	}
}

