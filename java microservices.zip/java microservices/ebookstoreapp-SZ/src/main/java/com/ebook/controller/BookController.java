package com.ebook.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ebook.entity.Book;
import com.ebook.service.BookService;

@RestController
@RequestMapping("/books")
public class BookController {

	private final BookService bookService;
	
	private Logger log = LoggerFactory.getLogger(BookController.class);

	@Autowired
	public BookController(BookService bookService) {
		this.bookService = bookService;
	}

	@PostMapping
	public void addBook(@RequestBody Book book) {
		bookService.addBook(book);
	}

	@PutMapping
	public void updateBook(@RequestBody Book book) {
		bookService.updateBook(book);
	}

	@GetMapping
	public List<Book> getAllBooks() {
		return bookService.getAllBooks();
	}

	@GetMapping("/{book_id}")
	public Optional<Book> getBookById(@PathVariable("book_id") Long bookId) {
		log.debug("getBookById with Id:" + bookId);
		Optional<Book> book= bookService.getBookById(bookId);
		log.debug("getBookById with return value book:" + book);
		return book;
	}

	@DeleteMapping("/{book_id}")
	public void deleteBookById(@PathVariable("book_id") Long bookId) {
		bookService.deleteBookById(bookId);
	}

	@GetMapping("/title/{book_title}")
	public List<Book> getBooksByTitle(@PathVariable("book_title") String title) {
		return bookService.getBooksByTitle(title);
	}

	@GetMapping("/publisher/{book_publisher}")
	public List<Book> getBooksByPublisher(@PathVariable("book_publisher") String publisher) {
		return bookService.getBooksByPublisher(publisher);
	}

	@GetMapping(params = "year")
	public List<Book> getBooksByYear(@RequestParam("year") int year) {
		return bookService.getBooksByYear(year);
	}
}
