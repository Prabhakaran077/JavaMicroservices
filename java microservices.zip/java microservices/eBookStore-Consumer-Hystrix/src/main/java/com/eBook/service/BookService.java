package com.eBook.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.eBook.entity.Book;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class BookService {

	@Autowired
	private RestTemplate restTemplate;

	@HystrixCommand(fallbackMethod = "fallbackMethodForGetBookById")
	public Optional<Book> getBookById(Long bookId) {
		Book book = restTemplate.getForObject("http://book-service/books/" + bookId, Book.class);
		return Optional.ofNullable(book);
	}

	public Optional<Book> fallbackMethodForGetBookById(Long bookId) {
		return Optional.ofNullable(new Book("Java MS 1", "RamNath", "978-1-61729-427-3", 256, 2014));
	}

}
